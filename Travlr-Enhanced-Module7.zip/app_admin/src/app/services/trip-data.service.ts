import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private apiBaseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) { }

  // GET all trips
  public getTrips(): Observable<Trip[]> {
    const headers = this.getAuthHeaders();

    return this.http.get<Trip[]>(
      `${this.apiBaseUrl}/trips`,
      { headers }
    );
  }

  // GET one trip
  public getTrip(tripCode: string): Observable<Trip> {
    const headers = this.getAuthHeaders();

    return this.http.get<Trip>(
      `${this.apiBaseUrl}/trips/${tripCode}`,
      { headers }
    );
  }

  // POST - Add trip
  public addTrip(trip: Trip): Observable<Trip> {
    const headers = this.getAuthHeaders();

    return this.http.post<Trip>(
      `${this.apiBaseUrl}/trips`,
      trip,
      { headers }
    );
  }

  // PUT - Update trip
  public updateTrip(tripCode: string, trip: Trip): Observable<Trip> {
    const headers = this.getAuthHeaders();

    return this.http.put<Trip>(
      `${this.apiBaseUrl}/trips/${tripCode}`,
      trip,
      { headers }
    );
  }

  // DELETE - Delete trip
  public deleteTrip(tripCode: string): Observable<any> {
    const headers = this.getAuthHeaders();

    return this.http.delete(
      `${this.apiBaseUrl}/trips/${tripCode}`,
      { headers }
    );
  }

  // Get JWT and create Authorization header
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('travlr-token');

    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }
}
