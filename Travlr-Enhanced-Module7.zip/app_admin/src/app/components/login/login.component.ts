import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  credentials = {
    email: '',
    password: ''
  };

  errorMessage = '';

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router
  ) {}

  onLogin(): void {
    this.errorMessage = '';

    this.authenticationService.login(this.credentials).subscribe({
      next: (response) => {
        if (response.token) {
          this.authenticationService.saveToken(response.token);
          this.router.navigate(['/']);
        }
      },
      error: (error) => {
        console.error(error);
        this.errorMessage = 'Invalid email or password.';
      }
    });
  }
}
