import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';

import { Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data.service';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrls: ['./edit-trip.component.css']
})
export class EditTripComponent implements OnInit {

  tripForm!: FormGroup;
  trip!: Trip;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {

  this.tripForm = this.formBuilder.group({
    code: ['', Validators.required],
    name: ['', Validators.required],
    length: ['', Validators.required],
    start: ['', Validators.required],
    resort: ['', Validators.required],
    perPerson: ['', Validators.required],
    image: ['', Validators.required],
    description: ['', Validators.required]
  });

  const tripCode = localStorage.getItem('tripCode');

  if (tripCode) {
    this.tripDataService.getTrip(tripCode).subscribe({
      next: (trip: Trip) => {
        this.trip = trip;

        this.tripForm.patchValue({
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: trip.start,
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description
        });
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

}

public onSubmit(): void {

  if (this.tripForm.valid) {

    this.tripDataService.updateTrip(
      this.trip.code,
      this.tripForm.value
    ).subscribe({

      next: () => {
        this.router.navigate(['']);
      },

      error: (err) => {
        console.error(err);
      }

    });

  }

}

public onDelete(): void {

  if (!this.trip || !this.trip.code) {
    return;
  }

  const confirmed = confirm(
    `Are you sure you want to delete the trip "${this.trip.name}"?`
  );

  if (!confirmed) {
    return;
  }

  this.tripDataService.deleteTrip(this.trip.code).subscribe({

    next: () => {
      console.log('Trip deleted successfully');
      this.router.navigate(['/trips']);
    },

    error: (err) => {
      console.error('Error deleting trip:', err);
    }

  });
}

}
