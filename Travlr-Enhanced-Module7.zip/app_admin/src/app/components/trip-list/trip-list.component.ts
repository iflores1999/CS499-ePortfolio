import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

import { Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data.service';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './trip-list.component.html',
  styleUrls: ['./trip-list.component.css']
})

export class TripListComponent implements OnInit {

  trips: Trip[] = [];

  constructor(
    private tripDataService: TripDataService,
    private router: Router
) { }

  ngOnInit(): void {
  this.tripDataService.getTrips().subscribe({
    next: (value: Trip[]) => {
      console.log('Trips received:', value);
      this.trips = value;
      console.log('Trips array:', this.trips);
    },
    error: (err) => {
      console.error('API Error:', err);
    }
  });
  }

  public addTrip(): void {
  this.router.navigate(['add-trip']);
}

  public editTrip(tripCode: string): void {

  localStorage.removeItem('tripCode');

  localStorage.setItem('tripCode', tripCode);

  this.router.navigate(['edit-trip', tripCode]);

}

}
