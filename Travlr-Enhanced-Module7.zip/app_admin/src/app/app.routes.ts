import { Routes } from '@angular/router';

import { TripListComponent } from './components/trip-list/trip-list.component';
import { AddTripComponent } from './components/add-trip/add-trip.component';
import { EditTripComponent } from './components/edit-trip/edit-trip.component';
import { LoginComponent } from './components/login/login.component';
import { authGuard } from './auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'add-trip',
    component: AddTripComponent,
    canActivate: [authGuard]
  },
  {
    path: 'edit-trip/:code',
    component: EditTripComponent,
    canActivate: [authGuard]
  },
  {
    path: 'trips',
    component: TripListComponent,
    canActivate: [authGuard]
  },
  {
    path: '',
    redirectTo: 'trips',
    pathMatch: 'full'
  }
];
