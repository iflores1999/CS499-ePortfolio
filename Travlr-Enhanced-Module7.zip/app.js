require('dotenv').config();

const express = require('express');
const path = require('path');
const hbs = require('hbs');
const cors = require('cors');
const passport = require('passport');

require('./db/connection');
require('./app_api/config/passport');

const app = express();

app.use(cors());
app.use(passport.initialize());
app.use(express.json());

app.use(express.urlencoded({ extended: false }));

app.set('views', path.join(__dirname, 'app_server/views'));

hbs.registerPartials(path.join(__dirname, 'app_server/views/partials'));

app.use(express.static(path.join(__dirname, 'public')));

app.use('/', require('./app_server/routes/index'));
app.use('/api', require('./app_api/routes/index'));

app.listen(3000, () => {
    console.log('Server running on port 3000');
});