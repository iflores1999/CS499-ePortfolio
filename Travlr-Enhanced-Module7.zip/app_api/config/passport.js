const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const User = require('../models/user');

// Local Strategy for login
passport.use(new LocalStrategy(
    {
        usernameField: 'email'
    },
    async (email, password, done) => {
        try {
            const user = await User.findOne({ email: email });

            if (!user) {
                return done(null, false, {
                    message: 'Incorrect email.'
                });
            }

            if (!user.validPassword(password)) {
                return done(null, false, {
                    message: 'Incorrect password.'
                });
            }

            return done(null, user);

        } catch (err) {
            return done(err);
        }
    }
));

// JWT Strategy for protected API endpoints
const jwtOptions = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: process.env.JWT_SECRET
};

passport.use(new JwtStrategy(
    jwtOptions,
    async (payload, done) => {
        try {
            const user = await User.findById(payload._id);

            if (!user) {
                return done(null, false);
            }

            return done(null, user);

        } catch (err) {
            return done(err, false);
        }
    }
));

module.exports = passport;