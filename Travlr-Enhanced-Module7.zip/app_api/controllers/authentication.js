const passport = require('passport');
const User = require('../models/user');

// Register a new user
const register = async (req, res) => {
    if (!req.body.name || !req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({ "message": "All fields required" });
    }

    try {
        const user = new User();

        user.name = req.body.name;
        user.email = req.body.email;

        user.setPassword(req.body.password);

        const savedUser = await user.save();

        const token = savedUser.generateJWT();

        res
            .status(200)
            .json({ token });

    } catch (err) {
    console.error(err);
    res
        .status(400)
        .json({ message: err.message });
}
};

// Login an existing user
const login = (req, res) => {
    passport.authenticate('local', { session: false }, (err, user, info) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        }

        if (!user) {
            return res.status(401).json({
                message: info ? info.message : 'Invalid email or password.'
            });
        }

        const token = user.generateJWT();

        return res.status(200).json({ token });
    })(req, res);
};

module.exports = {
    register,
    login
};