const express = require('express');
const router = express.Router();
const passport = require('passport');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

router.route('/trips')
    .get(
        passport.authenticate('jwt', { session: false }),
        tripsController.tripsList
    )
    .post(
        passport.authenticate('jwt', { session: false }),
        tripsController.tripsAddTrip
    );

router.route('/trips/:tripCode')
    .get(
        passport.authenticate('jwt', { session: false }),
        tripsController.tripsFindByCode
    )
    .put(
        passport.authenticate('jwt', { session: false }),
        tripsController.tripsUpdateTrip
    )
    .delete(
        passport.authenticate('jwt', { session: false }),
        tripsController.tripsDeleteTrip
    );

router
    .route('/register')
    .post(authController.register);

router
    .route('/login')
    .post(authController.login);

module.exports = router;