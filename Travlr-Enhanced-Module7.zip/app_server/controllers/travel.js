const travel = async (req, res) => {
    try {
        const response = await fetch('http://localhost:3000/api/trips');

        if (!response.ok) {
            throw new Error(`API request failed with status ${response.status}`);
        }

        const trips = await response.json();

        res.render('travel', {
            title: 'Travlr Getaways',
            currentPage: req.path,
            trips: trips
        });
    } catch (error) {
        console.error('Error retrieving trips from API:', error);

        res.status(500).render('travel', {
            title: 'Travlr Getaways',
            currentPage: req.path,
            trips: []
        });
    }
};

module.exports = {
    travel
};