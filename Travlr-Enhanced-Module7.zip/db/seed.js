const mongoose = require('mongoose');
require('./connection');

const Trip = mongoose.model('Trip');

const trips = require('../data/trips.json');

Trip.deleteMany({})
.then(() => {
    return Trip.insertMany(trips);
})
.then(() => {
    console.log('Trips inserted successfully');
    process.exit();
})
.catch(err => {
    console.log(err);
    process.exit();
});// JavaScript source code
